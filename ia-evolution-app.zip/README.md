# IA Evolution App

## Overview
The IA Evolution App is a web application designed to assist users in enhancing their gaming skills and academic performance through the use of artificial intelligence. The application features two distinct modes: **Gamer Mode** and **Student Mode**, allowing users to switch between them based on their current focus.

## Features
- **Gamer Mode**: Provides tools and resources tailored for gamers, including performance tracking, game strategy tips, and skill improvement exercises.
- **Student Mode**: Offers academic support with study resources, learning tools, and progress tracking to help users excel in their studies.
- **Mode Switcher**: A seamless interface that allows users to toggle between Gamer Mode and Student Mode effortlessly.

## Installation
To get started with the IA Evolution App, follow these steps:

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd ia-evolution-app
   ```

3. Install the dependencies:
   ```
   npm install
   ```

4. Start the development server:
   ```
   npm start
   ```

## Usage
Once the application is running, users can select their preferred mode using the Mode Switcher. Each mode will present a unique interface and set of features tailored to either gaming or academic pursuits.

## Contributing
Contributions are welcome! If you have suggestions for improvements or new features, please open an issue or submit a pull request.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.