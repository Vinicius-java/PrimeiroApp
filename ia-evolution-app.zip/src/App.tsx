import React, { useState } from 'react';
import ModeSwitcher from './components/ModeSwitcher';
import GamerMode from './components/GamerMode';
import StudentMode from './components/StudentMode';

const App: React.FC = () => {
    const [mode, setMode] = useState<'gamer' | 'student'>('gamer');

    const handleModeChange = (newMode: 'gamer' | 'student') => {
        setMode(newMode);
    };

    return (
        <div>
            <ModeSwitcher onModeChange={handleModeChange} />
            {mode === 'gamer' ? <GamerMode /> : <StudentMode />}
        </div>
    );
};

export default App;