export interface ModeProps {
    isActive: boolean;
    onSwitch: () => void;
}

export interface GamerModeProps {
    // Add any specific props for GamerMode here
}

export interface StudentModeProps {
    // Add any specific props for StudentMode here
}