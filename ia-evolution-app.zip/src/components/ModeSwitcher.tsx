import React, { useState } from 'react';
import GamerMode from '../../public/GamerMode';
import StudentMode from './StudentMode';

const ModeSwitcher: React.FC = () => {
    const [isGamerMode, setIsGamerMode] = useState(true);

    const toggleMode = () => {
        setIsGamerMode(!isGamerMode);
    };

    return (
        <div>
            <button onClick={toggleMode}>
                Switch to {isGamerMode ? 'Student' : 'Gamer'} Mode
            </button>
            {isGamerMode ? <GamerMode /> : <StudentMode />}
        </div>
    );
};

export default ModeSwitcher;